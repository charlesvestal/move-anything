#!/bin/bash
/opt/move/MoveLauncher