#!/usr/bin/env bash
LD_PRELOAD=control_surface_move_shim.so /opt/move/MoveOriginal
