
/*
================================================================================
RGB COLOR PALETTE (INDEXED 0–127)
================================================================================

--- NEUTRALS / GREYS -----------------------------------------------------------
  0 : #000000  Black
117 : #000000  Black (dup)
124 : #1A1A1A  Dark Grey
119 : #1A1A1A  Dark Grey (dup)
118 : #595959  Light Grey
121 : #595959  Light Grey (dup)
123 : #595959  Light Grey (dup)
120 : #FFFFFF  White
122 : #FFFFFF  White (dup)

--- REDS / PINKS / MAGENTAS ----------------------------------------------------
  1 : #FF2424  Bright Red
 27 : #A63421  Rust Red
 65 : #4D0B0B  Deep Red
 66 : #1A0404  Very Dark Red
 67 : #4D1204  Brick
 20 : #8700FF  Electric Violet
 21 : #E657E3  Hot Magenta
 23 : #FF0099  Neon Pink
 24 : #A14C5F  Rose
 25 : #FF4DC4  Bright Pink
 26 : #EB8BE1  Light Magenta
104 : #0D001A  Deep Violet
105 : #4D1D4C  Muted Violet
107 : #33004D  Dark Purple
109 : #4D002E  Deep Magenta
111 : #4D242D  Dusty Rose
113 : #4D173B  Mauve
114 : #1A0814  Deep Wine
115 : #4D2D49  Dusky Mauve
116 : #1A0F18  Shadow Mauve

--- ORANGES / AMBERS / YELLOWS -------------------------------------------------
  2 : #F23A0C  Orange Red
  3 : #FF9900  Bright Orange
  4 : #A68956  Tan / Muted Orange
  5 : #EDF95A  Light Yellow
  6 : #C19D08  Ochre
  7 : #FFFF00  Vivid Yellow
 28 : #995628  Burnt Orange
 29 : #876700  Mustard
 30 : #90821F  Yellow-Green
 73 : #4D491F  Dull Yellow
 74 : #1A180A  Very Dark Yellow
 75 : #403302  Brown-Yellow
 76 : #1A1501  Deep Brown-Yellow
 77 : #4D4D00  Olive
 78 : #1A1A00  Dark Olive

--- GREENS / TEALS -------------------------------------------------------------
  8 : #56BF13  Bright Green
  9 : #2C8403  Forest Green
 10 : #246B24  Dull Green
 11 : #19FF30  Neon Green
 12 : #159573  Teal Green
 13 : #176B50  Muted Teal
 14 : #00FFFF  Cyan
 31 : #4A8700  Lime
 32 : #007F12  Deep Green
 43 : #AEFF99  Pale Green
 44 : #7CDD9F  Mint Green
 45 : #89B47D  Olive Green
 79 : #1C4007  Dull Green
 80 : #0B1A03  Very Dark Green
 81 : #113301  Dull Olive
 83 : #113311  Dark Olive Green
 85 : #0A4D0A  Dark Grass Green
 87 : #073327  Dark Teal
 89 : #104D39  Muted Sea Green
 90 : #030D0A  Deep Teal

--- CYANS / AQUAS / BLUES ------------------------------------------------------
 15 : #0074FC  Azure Blue
 16 : #274FCC  Royal Blue
 17 : #00448C  Navy
 33 : #1853B2  Blue
 46 : #80F3FF  Pale Cyan
 47 : #7ACEFC  Sky Blue
 48 : #68A1D3  Light Blue
 49 : #858FC2  Muted Blue
 50 : #BBAAF2  Lavender Blue
 93 : #00234D  Deep Blue
 95 : #0C1940  Dark Blue
 97 : #00254D  Cool Blue
 99 : #231A4D  Indigo
100 : #0C091A  Deep Indigo
101 : #251E4D  Purple-Blue
102 : #0C0A1A  Dark Indigo
125 : #0000FF  Pure Blue

--- PURPLES / VIOLETS ---------------------------------------------------------
 18 : #644AD9  Blue-Violet
 19 : #4D3FA0  Violet
 22 : #660099  Purple
 34 : #624BAD  Lilac
 35 : #733A67  Mauve
106 : #1A0A19  Deep Plum
108 : #11001A  Dark Violet
110 : #1A000F  Wine Purple
112 : #1A0C0F  Dark Rose
115 : #4D2D49  Muted Violet (duplicate family)
 20–26 : also span violet–pink boundary (see REDS)


--- PRIMARY COLORS -------------------------------------------------------------
125 : #0000FF  Blue
126 : #00FF00  Green
127 : #FF0000  Red
================================================================================
*/

// --- NEUTRALS / GREYS ---
export const Black = 0;
export const DarkGrey = 124;
export const LightGrey = 118;
export const White = 120;

// --- REDS / PINKS / MAGENTAS ---
export const BrightRed = 1;
export const RustRed = 27;
export const DeepRed = 65;
export const VeryDarkRed = 66;
export const Brick = 67 ;
export const ElectricViolet = 20 ;
export const HotMagenta = 21;
export const NeonPink = 23;
export const Rose = 24;
export const BrightPink = 25;
export const LightMagenta = 26;
export const DeepViolet = 104;
export const MutedViolet = 105;
export const DarkPurple = 107;
export const DeepMagenta = 109;
export const DustyRose = 111;
export const Mauve = 113;
export const DeepWine = 114;
export const DuskyMauve = 115;
export const ShadowMauve = 116;

// --- ORANGES / AMBERS / YELLOWS ---
export const OrangeRed = 2;
export const Bright = 3;
export const Tan = 4;
export const LightYellow = 5;
export const Ochre = 6;
export const VividYellow = 7;
export const BurntOrange = 28;
export const Mustard = 29;
export const YellowGreen = 30;
export const DullYellow = 73;
export const VeryDarkYellow = 74;
export const BrownYellow = 75;
export const DeepBrownYellow = 76;
export const Olive = 77;
export const DarkOlive = 78;

// --- GREENS / TEALS ---
export const BrightGreen = 8;
export const ForestGreen = 9;
export const DullGreen = 10;
export const NeonGreen = 11;
export const TealGreen = 12;
export const MutedTeal = 13;
export const Cyan = 14;
export const Lime = 31;
export const DeepGreen = 32;
export const PaleGreen = 43;
export const MintGreen = 44;
export const OliveGreen = 45;
export const VeryDarkGreen = 80;
export const DullOlive = 81;
export const DarkOliveGreen = 83;
export const DarkGrassGreen = 85;
export const DarkTeal = 87;
export const MutedSeaGreen = 89;
export const DeepTeal = 90;

// --- CYANS / AQUAS / BLUES ---
export const AzureBlue = 15;
export const RoyalBlue = 16;
export const Navy = 17;
export const PaleCyan = 46;
export const SkyBlue = 47;
export const LightBlue = 48;
export const MutedBlue = 49;
export const LavenderBlue = 50;
export const DeepBlue = 93;
export const DarkBlue = 95;
export const CoolBlue = 97;
export const Indigo = 99;
export const DeepBlueIndigo = 100;
export const PurpleBlue = 101;
export const DarkIndigo = 102;
export const PureBlue = 125;

// --- PURPLES / VIOLETS ---
export const BlueViolet = 18;
export const Violet = 19;
export const Purple = 22;
export const Lilac = 34;
export const DeepPlum = 106;
export const DarkViolet = 108;
export const WinePurple = 110;
export const DarkRose = 112;

// --- PRIMARY COLORS ---
export const Blue = 125;
export const Green = 126;
export const Red = 127;

export const colours = [
  0,1,2,3,4,5,6,7,8,9,10,
  11,12,13,14,15,16,17,18,19,20
];

export const colourNames = {
  // -- NEUTRALS / GREYS ---
  0: "Black",
  117: "Black (dup)",
  124: "Dark Grey",
  119: "Dark Grey (dup)",
  118: "Light Grey",
  121: "Light Grey (dup)",
  123: "Light Grey (dup)",
  120: "White",
  122: "White (dup)",

  // --- REDS / PINKS / MAGENTAS ---
  1: "Bright Red",
  27: "Rust Red",
  65: "Deep Red",
  66: "Very Dark Red",
  67: "Brick",
  20: "Electric Violet",
  21: "Hot Magenta",
  23: "Neon Pink",
  24: "Rose",
  25: "Bright Pink",
  26: "Light Magenta",
  104: "Deep Violet",
  105: "Muted Violet",
  107: "Dark Purple",
  109: "Deep Magenta",
  111: "Dusty Rose",
  113: "Mauve",
  114: "Deep Wine",
  115: "Dusky Mauve",
  116: "Shadow Mauve",

  // --- ORANGES / AMBERS / YELLOWS ---
  2: "Orange Red",
  3: "Bright Orange",
  4: "Tan / Muted Orange",
  5: "Light Yellow",
  6: "Ochre",
  7: "Vivid Yellow",
  28: "Burnt Orange",
  29: "Mustard",
  30: "Yellow-Green",
  73: "Dull Yellow",
  74: "Very Dark Yellow",
  75: "Brown-Yellow",
  76: "Deep Brown-Yellow",
  77: "Olive",
  78: "Dark Olive",

  // --- GREENS / TEALS ---
  8: "Bright Green",
  9: "Forest Green",
  10: "Dull Green",
  11: "Neon Green",
  12: "Teal Green",
  13: "Muted Teal",
  14: "Cyan",
  31: "Lime",
  32: "Deep Green",
  43: "Pale Green",
  44: "Mint Green",
  45: "Olive Green",
  79: "Dull Green",
  80: "Very Dark Green",
  81: "Dull Olive",
  83: "Dark Olive Green",
  85: "Dark Grass Green",
  87: "Dark Teal",
  89: "Muted Sea Green",
  90: "Deep Teal",

  // --- CYANS / AQUAS / BLUES ---
  15: "Azure Blue",
  16: "Royal Blue",
  17: "Navy",
  33: "Blue",
  46: "Pale Cyan",
  47: "Sky Blue",
  48: "Light Blue",
  49: "Muted Blue",
  50: "Lavender Blue",
  93: "Deep Blue",
  95: "Dark Blue",
  97: "Cool Blue",
  99: "Indigo",
  100: "Deep Indigo",
  101: "Purple-Blue",
  102: "Dark Indigo",
  125: "Pure Blue",

  // --- PURPLES / VIOLETS ---
  18: "Blue-Violet",
  19: "Violet",
  22: "Purple",
  34: "Lilac",
  35: "Mauve",
  106: "Deep Plum",
  108: "Dark Violet",
  110: "Wine Purple",
  112: "Dark Rose",

  // --- PRIMARY COLORS ---
  125: "Blue",
  126: "Green",
  127: "Red"
};


// MIDI messages 
export const MidiNoteOff = 0x80;
export const MidiNoteOn = 0x90;
export const MidiPolyAftertouch = 0xA0;
export const MidiCC = 0xB0;
export const MidiPC = 0xC0;
export const MidiChAftertouch = 0xD0;
export const MidiWheel = 0xE0;
export const MidiSysexStart = 0xF0;
export const MidiSysexEnd = 0xF7;
export const MidiClock = 0xF8;


// Internal MIDI Notes
export const MoveKnob1Touch = 0;  // on = 127, off = 0
export const MoveKnob2Touch = 1;
export const MoveKnob3Touch = 2;
export const MoveKnob4Touch = 3;
export const MoveKnob5Touch = 4;
export const MoveKnob6Touch = 5;
export const MoveKnob7Touch = 6;
export const MoveKnob8Touch = 7;
export const MoveMasterTouch = 8;
export const MoveMainTouch = 9;
export const MoveStep1 = 16;   // and LED
export const MoveStep2 = 17;   // and LED
export const MoveStep3 = 18;   // and LED
export const MoveStep4 = 19;   // and LED
export const MoveStep5 = 20;   // and LED
export const MoveStep6 = 21;   // and LED
export const MoveStep7 = 22;   // and LED
export const MoveStep8 = 23;   // and LED
export const MoveStep9 = 24;   // and LED
export const MoveStep10 = 25;   // and LED
export const MoveStep11 = 26;   // and LED
export const MoveStep12 = 27;   // and LED
export const MoveStep13 = 28;   // and LED
export const MoveStep14 = 29;   // and LED
export const MoveStep15 = 30;   // and LED
export const MoveStep16 = 31;   // and LED
export const MovePad1 = 68;   // and LED
// PADs 68-99 from bottom left to top right
export const MovePad32 = 99;   // and LED

// Internal MIDI CCs
export const MoveMainButton = 3;   // no LED
export const MoveMainKnob = 14;   // no LED
export const MoveStep1UI = 16;   // LED only
export const MoveStep2UI = 17;   // LED only
export const MoveStep3UI = 18;   // LED only
export const MoveStep4UI = 19;   // LED only
export const MoveStep5UI = 20;   // LED only
export const MoveStep6UI = 21;   // LED only
export const MoveStep7UI = 22;   // LED only
export const MoveStep8UI = 23;   // LED only
export const MoveStep9UI = 24;   // LED only
export const MoveStep10UI = 25;   // LED only
export const MoveStep11UI = 26;   // LED only
export const MoveStep12UI = 27;   // LED only
export const MoveStep13UI = 28;   // LED only
export const MoveStep14UI = 29;   // LED only
export const MoveStep15UI = 30;   // LED only
export const MoveStep16UI = 31;   // LED only
export const MoveRow1 = 40;   // bottom row 
export const MoveRow2 = 41;
export const MoveRow3 = 42;
export const MoveRow4 = 43;
export const MoveShift = 49;
export const MoveMenu = 50;
export const MoveBack = 51;
export const MoveCapture = 52;
export const MoveDown = 54;
export const MoveUp = 55;
export const MoveUndo = 56;
export const MoveLoop = 58;
export const MoveCopy = 60;
export const MoveLeft = 62;
export const MoveRight = 63;
export const MoveKnob1 = 71;   // right = 1, left = 127
export const MoveKnob2 = 72;
export const MoveKnob3 = 73;
export const MoveKnob4 = 74;
export const MoveKnob5 = 75;
export const MoveKnob6 = 76;
export const MoveKnob7 = 77;
export const MoveKnob8 = 78;
export const MoveMaster = 79;   // no LED
export const MovePlay = 85;
export const MoveRec = 86;
export const MoveMute = 88;
export const MoveRecord = 118;
export const MoveDelete = 119;
