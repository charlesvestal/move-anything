from http.server import BaseHTTPRequestHandler, HTTPServer
import time

hostName = "move.local"
serverPort = 8888

class MyServer(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.end_headers()
        self.wfile.write(bytes("<html><head><title>Move Control Surface</title>", "utf-8"))
        self.wfile.write(bytes("<script>", "utf-8"))
        self.wfile.write(bytes("""
                                window.onload = ()=>{
                                let buttonElement= document.getElementById('button_go');
                                buttonElement.addEventListener('click', async ()=>{
                                    await fetch('/go');
                                });
                                }
                               """, "utf-8"))
        self.wfile.write(bytes("</script>", "utf-8"))

        self.wfile.write(bytes("</head>", "utf-8"))

        self.wfile.write(bytes('<body style="background-color:rgb(30,30,30)">', "utf-8"))
        # self.wfile.write(bytes("""<button onclick="console.log(await fetch('/go'));" style="background-color:rgb(255,96,0);border-radius:20px;width:200px;height:100px">Start Control Surface</button>""", "utf-8"))
        self.wfile.write(bytes("""<button id="button_go" style="background-color:rgb(255,96,0);border-radius:20px;width:200px;height:100px">Start Control Surface</button>""", "utf-8"))
        self.wfile.write(bytes("</body></html>", "utf-8"))

if __name__ == "__main__":        
    webServer = HTTPServer((hostName, serverPort), MyServer)
    print("Server started http://%s:%s" % (hostName, serverPort))

    try:
        webServer.serve_forever()
    except KeyboardInterrupt:
        pass

    webServer.server_close()
    print("Server stopped.")