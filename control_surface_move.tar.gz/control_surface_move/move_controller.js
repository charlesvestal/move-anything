import * as std from "std";
import * as cn from "./constants.mjs";

const notes = [...Array(127).keys()];

const drumNames = [
    "Empty",
    "Master",
    "Bass Drum",
    "BD",
    "Acou BD",
    "Snare",
    "Ac Snr",
    "El Snr",
    "Hihat",
    "Toms",
    "Hi Tom",
    "Mid Tom",
    "Low Tom",
    "Cymbals",
    "Rides",
    "Crash Cymbs",
];

const knobBanksDef = {
        71: "Bass Drum",
        72: "Snares",
        73: "Hihats",
        74: "Hi Tom",
        75: "Mid Tom",
        76: "Low Tom",
        77: "Rides",
        78: "Crash Cymbs",
        79: "Master"
};

var knobBanks = [];
knobBanks[0] = knobBanksDef;

const padBanksDef = {  // Blank init => PadMidiNote: [SentMidiNote, Colour, "Name"]
        68: [0, cn.LightGrey, "Empty"],
        69: [0, cn.LightGrey, "Empty"],
        70: [0, cn.LightGrey, "Empty"],
        71: [0, cn.LightGrey, "Empty"],
        72: [0, cn.LightGrey, "Empty"],
        73: [0, cn.LightGrey, "Empty"],
        74: [0, cn.LightGrey, "Empty"],
        75: [0, cn.LightGrey, "Empty"],
        76: [0, cn.LightGrey, "Empty"],
        77: [0, cn.LightGrey, "Empty"],
        78: [0, cn.LightGrey, "Empty"],
        79: [0, cn.LightGrey, "Empty"],
        80: [0, cn.LightGrey, "Empty"],
        81: [0, cn.LightGrey, "Empty"],
        82: [0, cn.LightGrey, "Empty"],
        83: [0, cn.LightGrey, "Empty"],
        84: [0, cn.LightGrey, "Empty"],
        85: [0, cn.LightGrey, "Empty"],
        86: [0, cn.LightGrey, "Empty"],
        87: [0, cn.LightGrey, "Empty"],
        88: [0, cn.LightGrey, "Empty"],
        89: [0, cn.LightGrey, "Empty"],
        90: [0, cn.LightGrey, "Empty"],
        91: [0, cn.LightGrey, "Empty"],
        92: [0, cn.LightGrey, "Empty"],
        93: [0, cn.LightGrey, "Empty"],
        94: [0, cn.LightGrey, "Empty"],
        95: [0, cn.LightGrey, "Empty"],
        96: [0, cn.LightGrey, "Empty"],
        97: [0, cn.LightGrey, "Empty"],
        98: [0, cn.LightGrey, "Empty"],
        99: [0, cn.LightGrey, "Empty"],
};

var padBanks = [];
padBanks[0] = padBanksDef;

// var padBanks = [
//     {  // MT-PowerDrumKit
//         68: [0, cn.Black, "Spare"],
//         69: [36, cn.VividYellow, "BD"],
//         70: [37, cn.Lime, "Stick"],
//         71: [40, cn.Lime, "E Snr"],
//         72: [42, cn.BrightPink, "HH Cl1"],
//         73: [44, cn.BrightPink, "HH Op1"],
//         74: [65, cn.BrightPink, "HH Pd"],
//         75: [0, cn.Black, "Spare"],
//         76: [0, cn.Black, "Spare"],
//         77: [35, cn.VividYellow, "Ac BD"],
//         78: [36, cn.VividYellow, "BD"],
//         79: [38, cn.Lime, "Snr"],
//         80: [42, cn.BrightPink, "HH Cl1"],
//         81: [46, cn.BrightPink, "HH Op2"],
//         82: [36, cn.VividYellow, "BD"],
//         83: [0, cn.Black, "Spare"],
//         84: [0, cn.Black, "Spare"],
//         85: [52, cn.Red, "Ch Cym"],
//         86: [49, cn.Red, "C Cym1"],
//         87: [48, cn.Blue, "H Tom"],
//         88: [45, cn.Blue, "M Tom"],
//         89: [41, cn.Blue, "L Tom"],
//         90: [38, cn.Lime, "Snr"],
//         91: [0, cn.Black, "Spare"],
//         92: [0, cn.Black, "Spare"],
//         93: [58, cn.Red, "CkCym2"],
//         94: [55, cn.Red, "Sp Cym"],
//         95: [57, cn.Red, "C Cym2"],
//         96: [51, cn.OrangeRed, "R Cym1"],
//         97: [53, cn.OrangeRed, "R CymB"],
//         98: [51, cn.OrangeRed, "R Cym1"],
//         99: [0, cn.Black, "Spare"]
//     },
//     { // GM mapping for M8
//         68: [0, cn.Black, "Spare"],
//         69: [39, cn.Lime, "Clap"],
//         70: [37, cn.Lime, "Stick"],
//         71: [40, cn.Lime, "E Snr"],
//         72: [44, cn.BrightPink, "HH Pd"],
//         73: [54, cn.BrightPink, "HH Cl2"],
//         74: [36, cn.VividYellow, "BD"],
//         75: [36, cn.VividYellow, "BD"],
//         76: [35, cn.VividYellow, "Ac BD"],
//         77: [36, cn.VividYellow, "BD"],
//         78: [36, cn.VividYellow, "BD"],
//         79: [38, cn.Lime, "Snr"],
//         80: [42, cn.BrightPink, "HH Cl1"],
//         81: [56, cn.BrightPink, "HH Op1"],
//         82: [46, cn.BrightPink, "HH Op2"],
//         83: [38, cn.Lime, "Snr"],
//         84: [0, cn.Black, "Spare"],
//         85: [52, cn.Red, "Ch Cym"],
//         86: [49, cn.Red, "C Cym1"],
//         87: [48, cn.Blue, "HMTom"],
//         88: [47, cn.Blue, "LMTom"],
//         89: [43, cn.Blue, "HFTom"],
//         90: [41, cn.Blue, "LFTom"],
//         91: [0, cn.Black, "Spare"],
//         92: [0, cn.Black, "Spare"],
//         93: [55, cn.Red, "Sp Cym"],
//         94: [57, cn.Red, "C Cym2"],
//         95: [50, cn.Blue, "H Tom"],
//         96: [51, cn.OrangeRed, "R Cym1"],
//         97: [53, cn.OrangeRed, "R CymB"],
//         98: [59, cn.OrangeRed, "R Cym2"],
//         99: [0, cn.Black, "Spare"]
//     },
//     { // Mapping for Cubasis on iPad 
//         68: [0, cn.Black, "Spare"],
//         69: [39, cn.Lime, "Clap"],
//         70: [37, cn.Lime, "Stick"],
//         71: [40, cn.Lime, "E Snr"],
//         72: [41, cn.BrightPink, "HH Pd"],
//         73: [36, cn.VividYellow, "BD"],
//         74: [36, cn.VividYellow, "BD"],
//         75: [0, cn.Black, "Spare"],
//         76: [0, cn.Black, "Spare"],
//         77: [35, cn.VividYellow, "Ac BD"],
//         78: [36, cn.VividYellow, "BD"],
//         79: [38, cn.Lime, "Snr"],
//         80: [42, cn.BrightPink, "HH Cl"],
//         81: [46, cn.BrightPink, "HH Op"],
//         82: [38, cn.Lime, "Snr"],
//         83: [0, cn.Black, "Spare"],
//         84: [0, cn.Black, "Spare"],
//         85: [0, cn.Black, "Spare"],
//         86: [48, cn.Red, "Crsh 1"],
//         87: [47, cn.Blue, "H Tom"],
//         88: [45, cn.Blue, "M Tom"],
//         89: [43, cn.Blue, "L Tom"],
//         90: [0, cn.Black, "Spare"],
//         91: [0, cn.Black, "Spare"],
//         92: [0, cn.Black, "Spare"],
//         93: [0, cn.Black, "Spare"],
//         94: [49, cn.Red, "Crsh 2"],
//         95: [44, cn.Red, "Crsh 3"],
//         96: [51, cn.OrangeRed, "R CymE"],
//         97: [50, cn.OrangeRed, "R CymB"],
//         98: [0, cn.Black, "Spare"],
//         99: [0, cn.Black, "Spare"]
//     }
// ];

let appName = "Move Drums";
let editMode = false;
let bank = 0;
let pads = padBanks[bank];
let knobs = knobBanks[bank];
let lastPad = 0;
let lastCC = 0;
let ccOrPadParam = 0;
let editModeOpt = 0;
let line1 = "";
let line2 = "";
let line3 = "";
let midiInt = move_midi_internal_send;


function clearLEDS() {
    let i = 0;
    while (i < 127) {
        midiInt([0 << 4 | (cn.MidiNoteOn / 16), cn.MidiNoteOn, i, cn.Black]);
        midiInt([0 << 4 | (cn.MidiCC / 16), cn.MidiCC, i, cn.Black]);
        i++;
    }
}

function fillColourPads(pads) {
    let i = cn.MovePad1;

    while (pads[i]) {
        let pad = pads[i];
        midiInt([0 << 4 | (cn.MidiNoteOn / 16), cn.MidiNoteOn, i, pad[1]]);
        i++;
    }
}

function saveConfig() {
    var f, fname = "config.json";

    f = std.open(fname, "w");
    f.puts(JSON.stringify([padBanks, knobBanks]));
    f.close();

    let str = std.loadFile(fname);
    console.log(`Content: ${str}`);
}

function textDisplay() {
    clear_screen();
    print(0, 0, line1, 1);
    print(0, 18, line2, 1);
    print(0, 32, line3, 1);
}

globalThis.onMidiMessageExternal = function (data) {
    if (
        data[0] === cn.MidiClock || 
        data[0] === cn.MidiChAftertouch ||
        data[0] === cn.MidiPolyAftertouch ||
        data[0] === cn.MidiSysexStart||
        data[0] === cn.MidiSysexEnd
    ) {
        // ignoring...
        return;
    }

    console.log(`onMidiMessageExternal ${data[0].toString(16)} ${data[1].toString(16)} ${data[2].toString(16)}`);

    midiInt([0 << 4 | (data[0] / 16), data[0], data[1], data[2]]);
};

globalThis.onMidiMessageInternal = function (data) {
    if (
        data[0] === cn.MidiClock || 
        data[0] === cn.MidiChAftertouch ||
        data[0] === cn.MidiPolyAftertouch ||
        data[0] === cn.MidiSysexStart||
        data[0] === cn.MidiSysexEnd
    ) {
        // ignoring...
        return;
    }

    console.log(`onMidiMessageInternal ${data[0].toString(16)} ${data[1].toString(16)} ${data[2].toString(16)}`);

    let isNote = data[0] === cn.MidiNoteOn || data[0] === cn.MidiNoteOff;
    let isNoteOn = data[0] === cn.MidiNoteOn;
    let isNoteOff = data[0] === cn.MidiNoteOff;
    let isCC = data[0] === cn.MidiCC;
    let note = data[1];

    if (isNote) {
        if (note >= cn.MovePad1 && note <= cn.MovePad32) {
            let pad = data[1];
            let velocity = data[2];
            let pads2Notes = pads[pad];
            //console.log(`Note data: ${noteData}`);
            move_midi_external_send([2 << 4 | (data[0] / 16), data[0], pads2Notes[0], velocity]);

            if (isNoteOn) {
                if (!editMode) {
                    midiInt([0 << 4 | (data[0] / 16), data[0], pad, cn.White]);
                    line1 = appName;
                    line2 = `Note ${pads2Notes[0]} => ${velocity}`;
                    line3 = `Pad ${pads2Notes[2]}`;
                    return;
                } else {
                    line1 = `EDIT - Pad ${pad}`;
                    line2 = `Nte ${pads2Notes[0]} Col ${pads2Notes[1]}`;
                    line3 = `Nam ${pads2Notes[2]}`;
                    lastPad = note;
                    lastCC = 0;
                    // colour row for edit mode
                    midiInt([0 << 4 | (cn.MidiCC / 16), cn.MidiCC, editModeOpt+cn.MoveRow1, cn.Red]);
                }
            } else if (isNoteOff) {
                midiInt([0 << 4 | (cn.MidiNoteOn / 16), cn.MidiNoteOn, pad, pads2Notes[1]]);
                return;
            }
        } else if (note >= cn.MoveStep1 && note <= cn.MoveStep16) {
            // clear previous bank (step) led
            midiInt([0 << 4 | (data[0] / 16), data[0], bank+16, cn.Black]);

            midiInt([0 << 4 | (data[0] / 16), data[0], data[1], cn.White]);
            bank = data[1]-16; // convert bank number to bank(step) led
            knobs = knobBanks[bank];
            pads = padBanks[bank];
            if (!knobs) {
                knobBanks[bank] = knobBanksDef;
                knobs = knobBanks[bank];
            }
            if (!pads) {
                padBanks[bank] = padBanksDef;
                pads = padBanks[bank];
            }
            fillColourPads(pads);

            line1 = appName;
            line2 =`Bank => ${bank}`;
            line3 = "";
        } else {
            move_midi_external_send([2 << 4 | (data[0] / 16), data[0], data[1], data[2]]);
            midiInt([0 << 4 | (data[0] / 16), data[0], data[1], cn.LightGrey]);
        }
    }

    if (isCC) {
        let ccNumber = data[1];
        let value = data[2];
        let valueText = "";
        let knobs = knobBanks[bank];
        let knobName = knobs[ccNumber];

        if (!editMode) {
            if (ccNumber >= cn.MoveKnob1 && ccNumber <= cn.MoveMaster) {
                if (value === 1 ) {
                    value = 127;
                    valueText = "+++"; 
                } else {
                    value = 1;
                    valueText = "---";
                }
            } else if (ccNumber === cn.MoveRecord && value === 127) {
                midiInt([0 << 4 | (cn.MidiCC / 16), cn.MidiCC, cn.MoveRecord, cn.Red]);
                midiInt([0 << 4 | (cn.MidiCC / 16), cn.MidiCC, editModeOpt+cn.MoveRow1, cn.Red]);
                line1 = appName;
                line2 = "EDIT MODE";
                line3 = "";
                console.log("Entered EDIT mode");
                editMode = true;
                return;
            } else if (ccNumber === cn.MoveRecord && value === 0) {
                return;
            } else if (ccNumber === cn.MoveUndo) {
                exit();
                return;
            } else {
                // midiInt([0 << 4 | (data[0] / 16), data[0], data[1], cn.LightGrey]);
                // find use for these other buttons
            }

            move_midi_external_send([2 << 4 | (data[0] / 16), data[0], data[1], data[2]]);

            line1 = appName;
            line2 = `CC ${ccNumber} => ${valueText}`;
            line3 = knobName;
        } else {
            let currentKnob = knobs[lastCC];
            let currentPad = pads[lastPad];
            if (ccNumber === cn.MoveRecord && value === 127) {
                midiInt([0 << 4 | (cn.MidiCC / 16), cn.MidiCC, cn.MoveRecord, cn.Black]);
                midiInt([0 << 4 | (cn.MidiCC / 16), cn.MidiCC, cn.MoveRow1, cn.Black]);
                midiInt([0 << 4 | (cn.MidiCC / 16), cn.MidiCC, cn.MoveRow2, cn.Black]);
                midiInt([0 << 4 | (cn.MidiCC / 16), cn.MidiCC, cn.MoveRow3, cn.Black]);
                midiInt([0 << 4 | (cn.MidiCC / 16), cn.MidiCC, cn.MoveRow4, cn.Black]);

                editMode = false;
                lastCC = 0;
                lastPad = 0;
                console.log("Exited EDIT mode");
                line1 = appName;
                line2 = "";
                line3 = "";
                saveConfig();
            } else if (ccNumber >= cn.MoveRow1 && ccNumber <= cn.MoveRow4) {
                midiInt([0 << 4 | (cn.MidiCC / 16), cn.MidiCC, editModeOpt+cn.MoveRow1, cn.Black]);
                editModeOpt = ccNumber - cn.MoveRow1;
                midiInt([0 << 4 | (cn.MidiCC / 16), cn.MidiCC, ccNumber, cn.Red]);
                let paramName = "";
                if (editModeOpt === 0) {
                    paramName = "MIDI Note";
                } else if (editModeOpt === 1) {
                    paramName = "Colour";
                } else if (editModeOpt === 2) {
                    paramName = "Name";
                }
                line1 = `EDIT`;
                line2 = `Param: ${editModeOpt}`;
                line3 = paramName;
            } else if (ccNumber === cn.MoveMainTouch && lastCC != 0) {
                line1 = `EDIT - CC ${lastCC}`;
                line2 = `Cur: ${currentKnob}`;
                line3 = "";
            } else if (ccNumber === cn.MoveMainKnob && lastCC != 0) {
                line1 = `EDIT - CC ${lastCC}`;
                line2 = `Cur: ${currentKnob}`;
                if (value === 127 && ccOrPadParam === 0) {
                    ccOrPadParam = drumNames.length;
                } else if (value === 127) {
                    ccOrPadParam--;
                } else if (value === 1 && ccOrPadParam === drumNames.length) {
                    ccOrPadParam = 0;
                } else if (value === 1) {
                    ccOrPadParam++;
                }
                line3 = `New: ${drumNames[ccOrPadParam]}`;
            } else if (ccNumber === cn.MoveMainButton && lastCC != 0) {
                knobBanks[bank][lastCC] = drumNames[ccOrPadParam];
                line1 = `EDIT - CC ${lastCC}`;
                line2 = `Cur: ${knobs[lastCC]}`;
                line3 = "";
            } else if (ccNumber === cn.MoveMainTouch && lastPad != 0) {
                line1 = "EDIT MODE";
                line2 = `Cur: ${currentPad}`;
                line3 = "";
            } else if (ccNumber === cn.MoveMainKnob && lastPad != 0) {
                var editParam;
                if (editModeOpt === 0) {
                    editParam = notes;
                } else if (editModeOpt === 1) {
                    editParam = cn.colours;
                    midiInt([0 << 4 | (cn.MidiNoteOn / 16), cn.MidiNoteOn, lastPad, editParam[ccOrPadParam]]);

                } else if (editModeOpt === 2) {
                    editParam = drumNames;
                }
                line1 = `EDIT - Pad ${lastPad}`;
                line2 = `Cur: ${currentPad[editModeOpt]}`;
                if (value === 127 && ccOrPadParam === 0) {
                    ccOrPadParam = editParam.length;
                } else if (value === 127) {
                    ccOrPadParam--;
                } else if (value === 1 && ccOrPadParam === editParam.length) {
                    ccOrPadParam = 0;
                } else if (value === 1) {
                    ccOrPadParam++;
                }
                line3 = `New: ${editParam[ccOrPadParam]}`;
            } else if (ccNumber === cn.MoveMainButton && lastPad != 0) {
                console.log();
                padBanks[bank][lastPad][editModeOpt] = editParam[ccOrPadParam];
                line1 = `EDIT - Pad ${lastPad}`;
                line2 = `Cur: ${currentPad[editModeOpt]}`;
                line3 = "";

            } else if (ccNumber >= cn.MoveKnob1 && ccNumber <= cn.MoveMaster) {
                lastCC = ccNumber;
                lastPad = 0;
                line1 = `EDIT - CC ${lastCC}`;
                line2 = `Cur: ${knobs[lastCC]}`;
                line3 = "";
            }
        }
    }
}

globalThis.init = function () {
    console.log("Custom Ableton Move controller started");

    line2 = appName;

    clearLEDS();
    fillColourPads(pads);

    // led for first bank
    midiInt([0 << 4 | (cn.MidiNoteOn / 16), cn.MidiNoteOn, cn.MoveStep1, cn.White]);

    // load config
    var f, fname = "config.json";
    let config = std.loadFile(fname);

    // create config if missing
    if (!config) {
        f = std.open(fname, "w");
        f.puts(JSON.stringify([padBanks, knobBanks]));
        f.close();
    } else {
        f = std.loadFile(fname);
        let configBanks = std.parseExtJSON(f);
        padBanks = configBanks[0];
        knobBanks = configBanks[1];
    }
 }

globalThis.tick = function(deltaTime) {
    textDisplay();
}
