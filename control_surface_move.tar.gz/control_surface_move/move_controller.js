import * as std from "std";
import * as cn from "./constants.mjs";

const ccs = Array.from({length: 128}, (x, i) => i);

const itemNames = [
    "Spare",
    "Main",
    "Dial",
    "Master",
    "Bass Drum",
    "BD",
    "Aco BD",
    "Snare",
    "Aco Snre",
    "Ele Snre",
    "Sd Stick",
    "Stick",
    "Hihat",
    "HH",
    "HH Open",
    "HH Clsd",
    "HH Ped",
    "Toms",
    "Hi Tom",
    "Mid Tom",
    "Low Tom",
    "HF Tom",
    "LF Tom",
    "Cymbals",
    "Rides",
    "Ride",
    "Ride 1",
    "Ride 2",
    "Ride Bell",
    "Crash Cym",
    "Crash",
    "Crash 1",
    "Crash 2",
    "Splash",
    "China",
    "Cowbell",
    "Bus",
    "Shift",
    "Menu",
    "Back",
    "Capture",
    "Undo",
    "Down",
    "Up",
    "Left",
    "Right",
    "Loop",
    "Copy",
    "Play",
    "Rec",
    "Mute",
    "Record",
    "Delete",
    "Rec",
    "Row1",
    "Row2",
    "Row3",
    "Row4",
    "Main",
    "Dial",
];

let bank = 0;
const ccBanksDef = {
//     3: {CC:3, Colour:cn.White, Name:1, Channel:0},
//     14: {CC:14, Colour:cn.White, Name:2, Channel:0},
//     40: {CC:40, Colour:cn.White, Name:"Row4", Channel:0},
//     41: {CC:41, Colour:cn.White, Name:"Row3", Channel:0},
//     42: {CC:42, Colour:cn.White, Name:"Row2", Channel:0},
//     43: {CC:43, Colour:cn.White, Name:"Row1", Channel:0},
//     49: {CC:49, Colour:cn.White, Name:"Shift", Channel:0},
//     50: {CC:50, Colour:cn.White, Name:"Menu", Channel:0},
//     51: {CC:51, Colour:cn.White, Name:"Back", Channel:0},
//     52: {CC:52, Colour:cn.White, Name:"Capture", Channel:0},
//     54: {CC:54, Colour:cn.White, Name:"Down", Channel:0},
//     55: {CC:55, Colour:cn.White, Name:"Up", Channel:0},
//     56: {CC:56, Colour:cn.White, Name:"Undo", Channel:0},
//     58: {CC:58, Colour:cn.White, Name:"Loop", Channel:0},
//     60: {CC:60, Colour:cn.White, Name:"Copy", Channel:0},
//     62: {CC:62, Colour:cn.White, Name:"Left", Channel:0},
//     63: {CC:63, Colour:cn.White, Name:"Right", Channel:0},
//     71: {CC:71, Colour:cn.White, Name:0, Channel:0},
//     72: {CC:72, Colour:cn.White, Name:0, Channel:0},
//     73: {CC:73, Colour:cn.White, Name:0, Channel:0},
//     74: {CC:74, Colour:cn.White, Name:0, Channel:0},
//     75: {CC:75, Colour:cn.White, Name:0, Channel:0},
//     76: {CC:76, Colour:cn.White, Name:0, Channel:0},
//     77: {CC:77, Colour:cn.White, Name:0, Channel:0},
//     78: {CC:78, Colour:cn.White, Name:0, Channel:0},
//     79: {CC:79, Colour:cn.White, Name:1, Channel:0},
//     85: {CC:85, Colour:cn.White, Name:"Play", Channel:0},
//     86: {CC:86, Colour:cn.White, Name:"Mec", Channel:0},
//     88: {CC:88, Colour:cn.White, Name:"Mute", Channel:0},
//     118: {CC:118, Colour:cn.White, Name:"Record", Channel:0},
//     119: {CC:119, Colour:cn.White, Name:"Delete", Channel:0}
    3: {CC:3, Colour:cn.White, Name:1, Channel:0},
    14: {CC:14, Colour:cn.White, Name:2, Channel:0},
    40: {CC:40, Colour:cn.White, Name:0, Channel:0},
    41: {CC:41, Colour:cn.White, Name:0, Channel:0},
    42: {CC:42, Colour:cn.White, Name:0, Channel:0},
    43: {CC:43, Colour:cn.White, Name:0, Channel:0},
    49: {CC:49, Colour:cn.White, Name:0, Channel:0},
    50: {CC:50, Colour:cn.White, Name:0, Channel:0},
    51: {CC:51, Colour:cn.White, Name:0, Channel:0},
    52: {CC:52, Colour:cn.White, Name:0, Channel:0},
    54: {CC:54, Colour:cn.White, Name:0, Channel:0},
    55: {CC:55, Colour:cn.White, Name:0, Channel:0},
    56: {CC:56, Colour:cn.White, Name:0, Channel:0},
    58: {CC:58, Colour:cn.White, Name:0, Channel:0},
    60: {CC:60, Colour:cn.White, Name:0, Channel:0},
    62: {CC:62, Colour:cn.White, Name:0, Channel:0},
    63: {CC:63, Colour:cn.White, Name:0, Channel:0},
    71: {CC:71, Colour:cn.White, Name:0, Channel:0},
    72: {CC:72, Colour:cn.White, Name:0, Channel:0},
    73: {CC:73, Colour:cn.White, Name:0, Channel:0},
    74: {CC:74, Colour:cn.White, Name:0, Channel:0},
    75: {CC:75, Colour:cn.White, Name:0, Channel:0},
    76: {CC:76, Colour:cn.White, Name:0, Channel:0},
    77: {CC:77, Colour:cn.White, Name:0, Channel:0},
    78: {CC:78, Colour:cn.White, Name:0, Channel:0},
    79: {CC:79, Colour:cn.White, Name:1, Channel:0},
    85: {CC:85, Colour:cn.White, Name:0, Channel:0},
    86: {CC:86, Colour:cn.White, Name:0, Channel:0},
    88: {CC:88, Colour:cn.White, Name:0, Channel:0},
    118: {CC:118, Colour:cn.White, Name:0, Channel:0},
    119: {CC:119, Colour:cn.White, Name:0, Channel:0}
};
var ccBanks = [];
ccBanks[bank] = JSON.parse(JSON.stringify(ccBanksDef));

const noteBanksDef = {
    68: {Note:0, Colour:cn.LightGrey, Name:0, Channel:0},
    69: {Note:0, Colour:cn.LightGrey, Name:0, Channel:0},
    70: {Note:0, Colour:cn.LightGrey, Name:0, Channel:0},
    71: {Note:0, Colour:cn.LightGrey, Name:0, Channel:0},
    72: {Note:0, Colour:cn.LightGrey, Name:0, Channel:0},
    73: {Note:0, Colour:cn.LightGrey, Name:0, Channel:0},
    74: {Note:0, Colour:cn.LightGrey, Name:0, Channel:0},
    75: {Note:0, Colour:cn.LightGrey, Name:0, Channel:0},
    76: {Note:0, Colour:cn.LightGrey, Name:0, Channel:0},
    77: {Note:0, Colour:cn.LightGrey, Name:0, Channel:0},
    78: {Note:0, Colour:cn.LightGrey, Name:0, Channel:0},
    79: {Note:0, Colour:cn.LightGrey, Name:0, Channel:0},
    80: {Note:0, Colour:cn.LightGrey, Name:0, Channel:0},
    81: {Note:0, Colour:cn.LightGrey, Name:0, Channel:0},
    82: {Note:0, Colour:cn.LightGrey, Name:0, Channel:0},
    83: {Note:0, Colour:cn.LightGrey, Name:0, Channel:0},
    84: {Note:0, Colour:cn.LightGrey, Name:0, Channel:0},
    85: {Note:0, Colour:cn.LightGrey, Name:0, Channel:0},
    86: {Note:0, Colour:cn.LightGrey, Name:0, Channel:0},
    87: {Note:0, Colour:cn.LightGrey, Name:0, Channel:0},
    88: {Note:0, Colour:cn.LightGrey, Name:0, Channel:0},
    89: {Note:0, Colour:cn.LightGrey, Name:0, Channel:0},
    90: {Note:0, Colour:cn.LightGrey, Name:0, Channel:0},
    91: {Note:0, Colour:cn.LightGrey, Name:0, Channel:0},
    92: {Note:0, Colour:cn.LightGrey, Name:0, Channel:0},
    93: {Note:0, Colour:cn.LightGrey, Name:0, Channel:0},
    94: {Note:0, Colour:cn.LightGrey, Name:0, Channel:0},
    95: {Note:0, Colour:cn.LightGrey, Name:0, Channel:0},
    96: {Note:0, Colour:cn.LightGrey, Name:0, Channel:0},
    97: {Note:0, Colour:cn.LightGrey, Name:0, Channel:0},
    98: {Note:0, Colour:cn.LightGrey, Name:0, Channel:0},
    99: {Note:0, Colour:cn.LightGrey, Name:0, Channel:0}
};
var noteBanks = [];
noteBanks[bank] = JSON.parse(JSON.stringify(noteBanksDef));

let ccParams = {
    0: {Name:"CC", Param:ccs},
    1: {Name:"Colour", Param:cn.colourNames},
    2: {Name:"Name", Param:itemNames},
    3: {Name:"Channel", Param:cn.MIDIChannels}
};
let noteParams = {
    0: {Name:"Note", Param:cn.midiNotes},
    1: {Name:"Colour", Param:cn.colourNames},
    2: {Name:"Name",  Param:itemNames},
    3: {Name:"Channel", Param:cn.MIDIChannels}
};

let noDisplay = false;
let editMode = false;
let lastNote = 0;
let lastCC = 0;
let ccOrNoteParam = 0;
let editModeOpt = 0;
var editParam;
let line1 = "";
let line2 = "";
let line3 = "";
let line4 = "";
var displayPrev;
let midiInt = move_midi_internal_send;

let appName = "MOVE CONTROLS";


function clearLEDS() {
    let i = 0;
    while (i < 127) {
        midiInt([0 << 4 | (cn.MidiNoteOn/16), cn.MidiNoteOn, i, cn.Black]);
        midiInt([0 << 4 | (cn.MidiCC/16), cn.MidiCC, i, cn.Black]);
        i++;
    }
}

function fillColours(notesOrCCs) {
    for (var key in notesOrCCs) {
        if (notesOrCCs.hasOwnProperty(key)) {
            midiInt([0 << 4 | (cn.MidiNoteOn/16), cn.MidiNoteOn, key, notesOrCCs[key].Colour]);
        }
    }
}

function updateDisplay() {
    clear_screen();
    print(0, 0, line1, 1);
    print(0, 17, line2, 1);
    print(0, 33, line3, 1);
    print(0, 50, line4, 1);
}

function display(l1=" ", l2=" ", l3=" ", l4=" ", temp=false) {
    line1 = l1;
    line2 = l2;
    line3 = l3;
    line4 = l4;
    if (!temp) {
        displayPrev = [l1, l2, l3, l4];
    }
}

function loadConfig() {
    var f, fname = "config.json";
    let config = std.loadFile(fname);

    if (config) {
        f = std.loadFile(fname);
        let configBanks = std.parseExtJSON(f);
        noteBanks = configBanks[0];
        ccBanks = configBanks[1];
    }

    fillColours(noteBanks[bank]);
    fillColours(ccBanks[bank]);
}


function saveConfig() {
    var f, fname = "config.json";

    f = std.open(fname, "w");
    f.puts(JSON.stringify([noteBanks, ccBanks]));
    f.close();

    let str = std.loadFile(fname);
    console.log(`Config Content: ${str}`);
}

globalThis.onMidiMessageExternal = function (data) {
    if (
        data[0] === cn.MidiClock ||
        data[0] === cn.MidiChAftertouch ||
        data[0] === cn.MidiPolyAftertouch ||
        data[0] === cn.MidiSysexStart||
        data[0] === cn.MidiSysexEnd
    ) {
        // ignoring...
        return;
    }

    console.log(`onMidiMessageExternal ${data[0].toString(16)} ${data[1].toString(16)} ${data[2].toString(16)}`);

    midiInt([0 << 4 | (data[0]/16), data[0], data[1], data[2]]);
};

globalThis.onMidiMessageInternal = function (data) {
    if (
        data[0] === cn.MidiClock ||
        data[0] === cn.MidiChAftertouch ||
        data[0] === cn.MidiPolyAftertouch ||
        data[0] === cn.MidiSysexStart||
        data[0] === cn.MidiSysexEnd
    ) {
        // ignoring...
        return;
    }

    console.log(`onMidiMessageInternal ${data[0].toString(16)} ${data[1].toString(16)} ${data[2].toString(16)}`);

    let isNote = data[0] === cn.MidiNoteOn || data[0] === cn.MidiNoteOff;
    let isNoteOn = data[0] === cn.MidiNoteOn;
    let isNoteOff = data[0] === cn.MidiNoteOff;
    let isCC = data[0] === cn.MidiCC;

    if (isNote) {
        let note = data[1];
        let velocity = data[2];

        if (note === cn.MoveMainTouch) {
            return;
        } else if (note >= cn.MoveStep1 && note <= cn.MoveStep16 && velocity === 127) {
            // change banks (16) via step buttons

            // clear previous bank (step) and light new bank (step) led
            midiInt([0 << 4 | (cn.MidiNoteOn/16), cn.MidiNoteOn, (bank + 16), cn.Black]);
            midiInt([0 << 4 | (cn.MidiNoteOn/16), cn.MidiNoteOn, note, cn.White]);

            // load bank data or if empty add default template
            bank = note - 16; // convert note number to bank(step)
            if (!ccBanks[bank]) {
                ccBanks[bank] = JSON.parse(JSON.stringify(ccBanksDef));
            }
            if (!noteBanks[bank]) {
                noteBanks[bank] = JSON.parse(JSON.stringify(noteBanksDef));
            }

            fillColours(ccBanks[bank]);
            fillColours(noteBanks[bank]);
            display(appName, `Bank => ${bank + 1}`);

        } else if (note >= cn.MoveKnob1Touch && note <= cn.MoveMasterTouch && velocity === 127) {
            // show paramater on knob touch

            let ccFromNote = note + 71;
            display(
                appName,
                `CC ${ccFromNote}`,
                itemNames[ccBanks[bank][ccFromNote].Name],
                `Touch Note ${note}`, true
            );
        } else if (note >= cn.MoveKnob1Touch && note <= cn.MoveMasterTouch && velocity === 0) {
            // return to previous display content on touch release

            display(displayPrev[0], displayPrev[1], displayPrev[2], displayPrev[3]);
        } else  if (cn.MovePads.includes(note)) {
            // all pads
            let pad = noteBanks[bank][note];

            // send modified MIDI note
            move_midi_external_send([2 << 4 | (data[0]/16), data[0], pad.Note, velocity]);

            if (isNoteOn) {
                if (!editMode) {
                    midiInt([0 << 4 | (data[0]/16), data[0], note, cn.White]);
                    display(
                        appName,
                        `Note ${cn.midiNotes[pad.Note]} (${pad.Note})}`,
                        `Name ${itemNames[pad.Name]}`,
                        `Velocity ${velocity}`
                    );
                    return;
                } else if (editMode) {
                    display(
                        "EDIT MODE",
                        `Note ${editParam[editModeOpt].Name}`
                    );

                    // colour row for edit mode
                    // midiInt([0 << 4 | (cn.MidiCC/16), cn.MidiCC, editModeOpt+cn.MoveRow4, cn.Red]);
                }
            } else if (isNoteOff) {
                if (editMode) {
                    if (lastCC != 0) {  // black out previous CC control led
                        midiInt([0 << 4 | (cn.MidiCC/16), cn.MidiCC, lastCC, cn.Black]);
                        lastCC = 0;
                    }
                    if (lastNote != 0 && lastNote != note) {   // pressing different pad to last time
                        midiInt([0 << 4 | (cn.MidiNoteOn/16), cn.MidiNoteOn, lastNote, noteBanks[bank][lastNote].Colour]);
                    }

                    midiInt([0 << 4 | (cn.MidiNoteOn/16), cn.MidiNoteOn, note, cn.White]);
                    midiInt([0 << 4 | ((cn.MidiNoteOn+cn.Pulse8th)/16), (cn.MidiNoteOn+cn.Pulse8th), note, pad.Colour]);

                } else if (!editMode) {
                    midiInt([0 << 4 | (cn.MidiNoteOn/16), cn.MidiNoteOn, note, pad.Colour]);
                }

                lastNote = note;
                ccOrNoteParam = noteBanks[bank][lastNote][editParam[editModeOpt].Name];

            }

            // move_midi_external_send([2 << 4 | (data[0]/16), data[0], data[1], data[2]]);
        }
    }

    if (isCC) {
        let ccNumber = data[1];
        let value = data[2];
        let valueText = "";

        if (!editMode) {
            if (
                ccNumber >= cn.MoveKnob1 &&
                ccNumber <= cn.MoveMaster ||
                ccNumber === cn.MoveMainKnob
            ) {
                // add +++ and --- indicators to knobs

                if (value === 1 ) {
                    value = 127;
                    valueText = "+++";
                } else {
                    value = 1;
                    valueText = "---";
                }

            } else if (ccNumber === cn.MoveMenu && value === 127) {
                // toggle display

                if (!noDisplay) {
                    midiInt([0 << 4 | (cn.MidiCC/16), cn.MidiCC, cn.MoveMenu, cn.Black]);
                    midiInt([0 << 4 | ((cn.MidiCC+cn.Pulse2th)/16), (cn.MidiCC+cn.Pulse2th), cn.MoveMenu]);
                    noDisplay = true;
                } else {
                    midiInt([0 << 4 | (cn.MidiCC/16), cn.MidiCC, cn.MoveMenu, cn.White]);
                    noDisplay = false;
                }

            } else if (ccNumber === cn.MoveRecord && value === 127) {
                // enter edit mode

                midiInt([0 << 4 | (cn.MidiCC/16), cn.MidiCC, cn.MoveCapture, cn.Black]);
                midiInt([0 << 4 | (cn.MidiCC/16), cn.MidiCC, cn.MoveRecord, cn.Black]);
                midiInt([0 << 4 | ((cn.MidiCC+cn.Pulse2th)/16), (cn.MidiCC+cn.Pulse2th), cn.MoveRecord, cn.Red]);
                midiInt([0 << 4 | (cn.MidiCC/16), cn.MidiCC, editModeOpt+cn.MoveRow4, cn.Red]);
                if (lastNote != 0) {
                    midiInt([0 << 4 | (cn.MidiNoteOn/16), cn.MidiNoteOn, lastNote, cn.White]);
                    midiInt([0 << 4 | ((cn.MidiNoteOn+cn.Pulse8th)/16), (cn.MidiNoteOn+cn.Pulse8th), lastNote, noteBanks[bank][lastNote].Colour]);
                }
                display("EDIT MODE", "Select Pad,", "Knob or Buttn", "to edit");
                console.log("Entered EDIT mode");
                editMode = true;
                return;

            } else if (ccNumber === cn.MoveRecord && value === 0) {
                return;  // ignore
            } else if (ccNumber === cn.MoveCapture) {
                exit();  // exit to Move interface
            } else {
                // maybe find use for the other buttons
            }

            // send midi externally and display details on display
            move_midi_external_send([2 << 4 | (data[0]/16), data[0], data[1], data[2]]);
            display(appName, `CC ${ccNumber} => ${valueText}`, itemNames[ccBanks[bank][ccNumber].Name]);

        } else if (editMode) {  // in edit mode
            if (lastCC != 0) {
                editParam = ccParams;
            } else {
                editParam = noteParams;
            }

            if (
                ccNumber === cn.MoveRecord && value === 0 ||
                ccNumber === cn.MoveMainButton && value === 0
            ) {
                return; // ignore buttons
            } else if (ccNumber === cn.MoveRecord && value === 127) {
                // exit editing mode

                midiInt([0 << 4 | (cn.MidiCC/16), cn.MidiCC, cn.MoveRecord, cn.Black]);
                midiInt([0 << 4 | (cn.MidiCC/16), cn.MidiCC, cn.MoveRow1, cn.Black]);
                midiInt([0 << 4 | (cn.MidiCC/16), cn.MidiCC, cn.MoveRow2, cn.Black]);
                midiInt([0 << 4 | (cn.MidiCC/16), cn.MidiCC, cn.MoveRow3, cn.Black]);
                midiInt([0 << 4 | (cn.MidiCC/16), cn.MidiCC, cn.MoveRow4, cn.Black]);
                midiInt([0 << 4 | (cn.MidiCC/16), cn.MidiCC, cn.MoveRecord, cn.Blue]);
                midiInt([0 << 4 | (cn.MidiCC/16), cn.MidiCC, cn.MoveCapture, cn.White]);
                midiInt([0 << 4 | (cn.MidiCC/16), cn.MidiCC, lastCC, cn.Black]);

                fillColours(ccBanks[bank]);
                fillColours(noteBanks[bank]);
                editMode = false;
                // lastCC = 0;
                // lastNote = 0;
                // ccOrNoteParam = 0;
                console.log("Exited EDIT mode");
                display(appName);
                saveConfig();
            } else if (ccNumber >= cn.MoveRow4 && ccNumber <= cn.MoveRow1) {
                // change edit parameter selection (note, colour, name)

                midiInt([0 << 4 | (cn.MidiCC/16), cn.MidiCC, editModeOpt+cn.MoveRow4, cn.Black]);
                editModeOpt = ccNumber - cn.MoveRow4;
                midiInt([0 << 4 | (cn.MidiCC/16), cn.MidiCC, ccNumber, cn.Red]);
                if (lastCC != 0) {
                    display("EDIT MODE", `CC ${editParam[editModeOpt].Name}`);
                } else {
                    display("EDIT MODE", `Note ${editParam[editModeOpt].Name}`);
                }

            } else if (
                ccNumber === cn.MoveMainKnob && lastCC != 0 ||
                ccNumber === cn.MoveMainKnob && lastNote != 0
            ) {
                // edit note or CC settings

                line4 = "";
                // console.log(JSON.stringify(editParam[editModeOpt].Param));

                if (ccOrNoteParam > editParam[editModeOpt].Param.length || ccOrNoteParam === undefined) {
                    ccOrNoteParam = 0;   // if previous used param value bigger than current available, reset
                }
                if (ccOrNoteParam === 0 && value === 127) {
                    ccOrNoteParam = Object.keys(editParam[editModeOpt].Param).length - 1;
                } else if (value === 127) {
                    ccOrNoteParam--;
                } else if (value === 1 && ccOrNoteParam === Object.keys(editParam[editModeOpt].Param).length - 1) {
                    ccOrNoteParam = 0;
                } else if (value === 1) {
                    ccOrNoteParam++;
                }
                if (lastCC != 0 && editModeOpt === 1) {   // show colour changes
                    midiInt([0 << 4 | (cn.MidiCC/16), cn.MidiCC, lastCC, ccOrNoteParam]);

                } else if (lastNote != 0 && editModeOpt === 1) {   // show colour changes
                    midiInt([0 << 4 | (cn.MidiNoteOn/16), cn.MidiNoteOn, lastNote, ccOrNoteParam]);
                }
                line3 = `${editParam[editModeOpt].Param[ccOrNoteParam]} (${ccOrNoteParam})`;

            } else if (ccNumber === cn.MoveMainButton && lastCC != 0 && value === 127) {
                // save cc changes to cc banks

                console.log(editParam[editModeOpt].Name);
                ccBanks[bank][lastCC][editParam[editModeOpt].Name] = ccOrNoteParam;
                line3 = `${editParam[editModeOpt].Param[ccBanks[bank][lastCC][editParam[editModeOpt]]]} (${ccBanks[bank][lastCC][editParam[editModeOpt]]})`;

            } else if (ccNumber === cn.MoveMainButton && lastNote != 0 && value === 127) {
                // save note changes to note bank

                console.log(editParam[editModeOpt].Name);
                noteBanks[bank][lastNote][editParam[editModeOpt].Name] = ccOrNoteParam;

                line3 = `${editParam[editModeOpt].Param[ccBanks[bank][lastNote][editParam[editModeOpt]]]} (${ccBanks[bank][lastNote][editParam[editModeOpt]]})`;

                midiInt([0 << 4 | (cn.MidiNoteOn/16), cn.MidiNoteOn, lastNote, cn.White]);
                midiInt([0 << 4 | ((cn.MidiNoteOn+cn.Pulse8th)/16), (cn.MidiNoteOn+cn.Pulse8th), lastNote, noteBanks[bank][lastNote].Colour]);
            } else if (ccNumber >= cn.MoveMainButton && ccNumber <= cn.MoveDelete) {
                // flashing led control
                if (lastNote != 0) {
                    midiInt([0 << 4 | (cn.MidiNoteOn/16), cn.MidiNoteOn, lastNote, noteBanks[bank][lastNote].Colour]);
                    lastNote = 0;
                }
                if (lastCC != 0) {
                    midiInt([0 << 4 | ((cn.MidiCC+cn.Pulse4th)/16), (cn.MidiCC+cn.Pulse4th), lastCC, ccBanks[bank][lastCC].Colour]);
                }
                if (lastCC != ccNumber) {
                    midiInt([0 << 4 | (cn.MidiCC/16), cn.MidiCC, lastCC, cn.Black]);
                }

                lastCC = ccNumber;
                ccOrNoteParam = ccBanks[bank][lastCC][editParam[editModeOpt].Name];

                line3 = `${editParam[editModeOpt].Param[ccBanks[bank][lastCC][editParam[editModeOpt].Name]]} (${ccBanks[bank][lastCC][editParam[editModeOpt].Name]})`;
            }
        }
    }
};

globalThis.init = function () {
    console.log("======================================");
    console.log("Custom Ableton Move controller started");
    console.log("======================================");

    display(appName);

    // clearLEDS();

    // led for Capture (exit)
    midiInt([0 << 4 | (cn.MidiCC/16), cn.MidiCC, cn.MoveCapture, cn.White]);
    // led for Record (edit)
    midiInt([0 << 4 | (cn.MidiCC/16), cn.MidiCC, cn.MoveRecord, cn.Blue]);
    // led for Menu (no display mode)
    midiInt([0 << 4 | (cn.MidiCC/16), cn.MidiCC, cn.MoveMenu, cn.White]);
    // led for first bank
    midiInt([0 << 4 | (cn.MidiNoteOn/16), cn.MidiNoteOn, cn.MoveStep1, cn.White]);

    loadConfig();
};

globalThis.tick = function(deltaTime) {
    if (!noDisplay) {
        updateDisplay();
    }
};
