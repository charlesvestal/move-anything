#!/usr/bin/env bash
LD_PRELOAD=move-anything-shim.so /opt/move/MoveOriginal
