#!/usr/bin/env bash
killall move-anything
